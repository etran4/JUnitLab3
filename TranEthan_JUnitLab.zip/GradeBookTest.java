import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GradeBookTest {
	GradeBook o1;
	GradeBook o2;

	@BeforeEach
	void setUp() throws Exception {
		o1 = new GradeBook(5);
		o2 = new GradeBook(5);

		o1.addScore(2);
		o1.addScore(3);
		o2.addScore(5);
		o2.addScore(6);
	}

	@AfterEach
	void tearDown() throws Exception {
		o1 = null;
		o2 = null;
	}

	@Test
	void testAddScore() {
		assertTrue(o1.toString().equals("2.0 3.0 "));
		assertTrue(o2.toString().equals("5.0 6.0 "));

		assertEquals(o1.getScoreSize(), 2);
		assertEquals(o2.getScoreSize(), 2);
	}

	@Test
	void testSum() {
		assertEquals(o1.sum(), 5);
		assertEquals(o2.sum(), 11);
	}

	@Test
	void testMinimum() {
		assertEquals(o1.minimum(), 2);
		assertEquals(o2.minimum(), 5);
	}

	@Test
	void testFinalScore() {
		assertEquals(o1.finalScore(), 3);
		assertEquals(o2.finalScore(), 6);
	}
}
